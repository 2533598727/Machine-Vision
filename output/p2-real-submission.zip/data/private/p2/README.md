# P2 工作照片与最终标注

12 张用户提供的教材页照片，原始文件名 IMG_0258.JPG 至 IMG_0269.JPG。IMG_0260.JPG 为参考，11 张场景图每图 20–24 对对应点，共 250 对。

`images/` 是 960×1280 的等比例工作副本，未作透视拉正，并已去掉 EXIF/GPS；D 盘原图没有修改。`manifest.json` 保存原图尺寸和 SHA-256，`annotations/` 保存最终点对及来源。

标注是助手视觉选点、局部灰度配准辅助及助手放大核对结果，不是经认证的人类手工标注。状态 `assistant_visual_verified`、`human_verified=false`。教材页也不是指定的板书/试卷。

坐标使用工作图左上角原点的 `[x,y]`；`reference_original` 和 `scene_original` 是像素中心换算后的原图等效坐标。点号不必连续。全部评测设置共享同一图对的标注凸包 ROI。

详细复现步骤见提交包根目录 P2_REAL_README.md。最终 JSON 是复现输入；重新导入原图会重写助手复核状态。此目录被 Git 忽略，但本版作业 ZIP 显式包含它。
